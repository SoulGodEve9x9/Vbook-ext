function execute(url) {
    let mangaId = url.split('/').pop();
    let apiUrl = `https://mimihentai.com/api/v1/manga/info/${mangaId}`;
    
    let response = fetch(apiUrl);
    if (!response.ok) return Response.error("Lỗi kết nối API");
    
    let json = response.json();
    let basicInfo = json.basicInfo || {};
    let relationInfo = json.relationInfo || {};
    
    let genres = [];
    if (relationInfo.genres && relationInfo.genres.length > 0) {
        genres = relationInfo.genres.map(genre => ({
            title: genre.name,
            input: `https://mimihentai.com/api/v1/manga/manga/by-genre/${genre.id}?page=0`,
            script: "homecontent.js"
        }));
    }
    
    let ongoing = basicInfo.status ? 
        (basicInfo.status.toLowerCase().includes('ongoing') || 
         basicInfo.status.toLowerCase().includes('đang') ||
         basicInfo.status.toLowerCase().includes('updating')) 
        : false;
    
    let authors = (relationInfo.authors && relationInfo.authors.length > 0) 
        ? relationInfo.authors.join(', ') 
        : 'Không rõ';
    
    let detail = [
        `Lượt xem: ${basicInfo.views || 'Chưa có'}`,
        `Người đăng: ${json.uploaderName || 'Không rõ'}`,
        `Trạng thái: ${ongoing ? 'Đang cập nhật' : 'Hoàn thành'}`,
        `Ngày cập nhật: ${basicInfo.updatedAt ? new Date(basicInfo.updatedAt).toLocaleDateString() : 'Không rõ'}`
    ].join('\n');
    
    return Response.success({
        name: basicInfo.title || '',
        cover: basicInfo.coverUrl || '',
        host: "https://mimihentai.com",
        author: authors,
        description: basicInfo.description || basicInfo.fdescription || '',
        detail: detail,
        ongoing: ongoing,
        genres: genres,
        suggests: [
            {
                title: "Truyện Ngẫu Nhiên",
                input: "https://mimihentai.com/api/v1/manga/random?limit=20",
                script: "suggest.js"
            }
        ]
    });
}