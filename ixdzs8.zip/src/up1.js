load('config.js');
function execute(url) {
    url = url.replace(/^(?:https?:\/\/)?(?:[^@\n]+@)?(?:www\.)?([^:\/\n?]+)/img, BASE_URL);
    let response = fetch(BASE_URL + url);
    if (response.ok) {
        let doc = response.html();
        const data = [];
        doc.select(".u-list li").forEach(e => {
          data.push({
            name: e.select("h3 a").first().text(),
            link: BASE_URL + e.select("a").first().attr("href"),
            cover: e.select("a img").attr("src"),
            description: e.select(".l-chapter").text(),
            host: BASE_URL
          })
        });
        return Response.success(data)
    }
    return null;
}