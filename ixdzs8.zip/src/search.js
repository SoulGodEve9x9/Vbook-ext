load("config.js");

function execute(url,key) {
    url = url.replace(/^(?:https?:\/\/)?(?:[^@\n]+@)?(?:www\.)?([^:\/\n?]+)/img, BASE_URL);
    let response = fetch(BASE_URL + "/bsearch?q=" + key);

    if (response.ok) {
        let doc = response.html();
        const books = [];
        doc.select(".u-list li").forEach(e => {
            books.push({
                name: e.select("h3").last().text(),
                link: BASE_URL + e.attr("data-url"),
                cover: e.select("a img").attr("src"),
                description: e.select(".l-chapter").text(),
                host: BASE_URL
            });
        });
        return Response.success(books);
    }

    return null;
}