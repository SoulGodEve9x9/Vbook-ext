let BASE_URL = 'https://ixdzs8.tw';
try {
    if (CONFIG_URL) {
        BASE_URL = CONFIG_URL;
    }
} catch (error) {
}