load('config.js');

function execute(url) {
    url = url.replace(/^(?:https?:\/\/)?(?:[^@\n]+@)?(?:www\.)?([^:\/\n?]+)/img, BASE_URL);
    
    // Extract bookId from URL
    var bookId = "";
    var match = url.match(/\/read\/(\d+)/);
    if (match) {
        bookId = match[1];
    }
    
    if (!bookId) {
        return Response.error("Cannot extract book ID from URL");
    }
    
    var response = fetch(url);
    if (!response.ok) {
        return Response.error("Cannot fetch page");
    }
    
    var doc = response.html();
    var chapters = [];
    var start = 1;
    var end = 1;
    
    try {
        // Get first chapter link
        var firstChapterLink = doc.select("#readbtn a").first();
        if (!firstChapterLink) {
            firstChapterLink = doc.select("a[href*='/p'][href*='.html']").first();
        }
        
        if (firstChapterLink) {
            var firstHref = firstChapterLink.attr("href");
            var startMatch = firstHref.match(/\/p(\d+)\.html/);
            if (startMatch) {
                start = parseInt(startMatch[1]);
            }
        }
        
        // Get last chapter link - get FIRST link which is the latest chapter
        var lastChapterLink = doc.select(".u-chapter a").first();
        if (!lastChapterLink) {
            lastChapterLink = doc.select("a[href*='/p'][href*='.html']").first();
        }
        
        if (lastChapterLink) {
            var lastHref = lastChapterLink.attr("href");
            var endMatch = lastHref.match(/\/p(\d+)\.html/);
            if (endMatch) {
                end = parseInt(endMatch[1]);
            }
        }
        
        // Generate chapter list
        if (end >= start && end - start < 10000) {
            for (var i = start; i <= end; i++) {
                var chapterName = "第" + i + "章";
                var chapterUrl = "/read/" + bookId + "/p" + i + ".html";
                
                chapters.push({
                    name: chapterName,
                    url: chapterUrl,
                    host: BASE_URL
                });
            }
        } else {
            // Fallback to single chapter
            chapters.push({
                name: "正文",
                url: "/read/" + bookId + "/p1.html",
                host: BASE_URL
            });
        }
        
    } catch (e) {
        return Response.error("Error generating chapter list: " + e.toString());
    }
    
    return Response.success(chapters);
}
