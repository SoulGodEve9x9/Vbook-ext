load('config.js');

function execute(url) {
    url = url.replace(/^(?:https?:\/\/)?(?:[^@\n]+@)?(?:www\.)?([^:\/\n?]+)/img, BASE_URL);
    
    var response = fetch(url);
    if (!response.ok) {
        return Response.error("Cannot fetch page");
    }
    
    var doc = response.html();
    
    // Remove unwanted elements
    doc.select("script").remove();
    doc.select(".bottem2").remove();
    doc.select("ins").remove(); // Remove ads
    doc.select(".abg").remove(); // Remove ad containers
    doc.select("[data-zoneid]").remove(); // Remove ad zones
    
    var content = doc.select(".page-content");
    if (!content || content.isEmpty()) {
        return Response.error("Cannot find chapter content");
    }
    
    var htm = content.html();
    htm = cleanHtml(htm);
    
    return Response.success(htm);
}

//clear rác
function cleanHtml(htm) {
    // Remove excessive line breaks
    htm = htm.replace(/(<br>\s*){2,}/g, '<br>');
    
    // Remove links but keep text content
    htm = htm.replace(/<a[^>]*>([^<]+)<\/a>/g, '$1');
    
    // Clean HTML entities
    htm = htm.replace(/&(nbsp|amp|quot|lt|gt);/g, "");
    htm = htm.replace(/\&nbsp;/g, " ");
    
    // Remove HTML comments
    htm = htm.replace(/<!--(<br \/>)?[^>]*-->/gm, '');
    
    // Remove specific site watermarks
    htm = htm.replace(/3Q中文网 www\.3qzone\.io，最快更新魔门败类 ！ /g, '');
    htm = htm.replace(/喜欢我有一百个分身请大家收藏：\(www\.soxscc\.net\)我有一百个分身搜小说更新速度全网最快。/g, '');
    
    // Remove AdProvider scripts
    htm = htm.replace(/\(AdProvider = window\.AdProvider.*?\)\;/g, '');
    
    // Convert p tags to br tags
    htm = htm.replace(/<\/p>/g, '<br>');
    htm = htm.replace(/<p[^>]*>/g, '');
    
    // Convert section tags to br tags
    htm = htm.replace(/<\/section>/g, '<br>');
    htm = htm.replace(/<section[^>]*>/g, '<br>');
    
    // Remove extra whitespace
    htm = htm.replace(/\s+/g, ' ');
    htm = htm.replace(/>\s+</g, '><');
    
    // Clean up multiple br tags
    htm = htm.replace(/(<br>\s*){3,}/g, '<br><br>');
    
    return htm.trim();
}